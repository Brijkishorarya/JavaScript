//for loop 
for (let i = 0; i <= 50; i++) {
    console.log(i)   
}

//while loop 
let i = 1; 
while(i <= 50){
    console.log("brijkishor arya")
    i++; 
}

// do loop 
let j = 1; 
do {
    console.log("Guddu bhaiya"); 
    j++; 
} while(j <= 10);

//for-of loop 

let str = "Brijkishor"; 

let size = 0; 
for(let val of str){
    console.log(val);
    size++;  
}

console.log("String size = ", size); 

//for-in loop 
let student = {
    name: "Rahul kumar", 
    age: 20, 
    cgpa: 7.5, 
    isPass: true, 
}; 

for(let key in student){
    console.log("key = ", key, "value = ", student[key]); 
}