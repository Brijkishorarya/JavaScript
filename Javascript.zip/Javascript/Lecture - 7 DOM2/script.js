// let div = document.querySelector("div"); 
// console.log(div); 

// let id = div.getAttribute("id"); 
// console.log(id); 

// let name = div.getAttribute("name"); 
// console.log(name);

let div = document.querySelector("div"); 

div.style.background