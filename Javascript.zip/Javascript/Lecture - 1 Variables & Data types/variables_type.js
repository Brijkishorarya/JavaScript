var age = 24; 
console.log(age);  
var age = 59; 

var age = 65; 

console.log(age); 