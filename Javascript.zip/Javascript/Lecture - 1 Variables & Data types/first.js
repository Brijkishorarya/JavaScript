console.log(" hii  Welcome Brijkisor Arya"); 
age = 24;
console.log(age); 
age + 1; 
console.log(age); 
fullname = "Guddu bhaiya"; 
console.log(fullname); 
price = 24.5; 
console.log(price); 
x = null; 
console.log(x); 
y = undefined; 
console.log(y); 
isFollow = false; 
console.log(isFollow); 
isFollows = true; 
console.log(isFollows); 



