//primitive data types (given 7)
//Number
let age = 25;  
console.log(age);
console.log(typeof(age)); 

//String
let fullName = "Brijkishor arya";
console.log(fullName);  
console.log(typeof(fullName));

//Boolean
let isFollow = true; 
console.log(isFollow); 
console.log(typeof(isFollow));

//Undefined
let x;  
console.log(x);
console.log(typeof(x));

//Null
let y; 
console.log(y); 
console.log(typeof(y));

//bigInt
let m = BigInt("123");  
console.log(m);
console.log(typeof(m));

//symbol 
let n = Symbol; 
console.log(n); 
console.log(typeof(Symbol));


//Non-primitive data types (object & array)
const student = {
    fullName : "Rahul kumar", 
    age : 20, 
    cgpa: 8.2, 
    isPass: true, 
}; 

console.log(student);
console.log(typeof(student));