let marks = [97, 98, 99,, 95, 87]; 
console.log(marks); 
console.log(marks.length); 