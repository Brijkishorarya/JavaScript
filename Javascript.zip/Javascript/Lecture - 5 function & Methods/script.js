// function myFunction(msg, n) {
//     // paramether -> input 
//     console.log(msg * n); 
//     console.log("Welcome to GLA"); 
//     console.log("Revision of js");
// }



// myFunction("I love JS", 100);// argument 
// myFunction(); 

//function -> 2 numbers, sum 

// function sum(x, y){
//     console.log(x+y); 
// }

// sum(4, 5); 


// function sum(x, y){
//     s = x+y; 
//     return s;  
// }

// sum(4, 5); 

//arrow function 

//fur sum arrow function 
// const arrowSum = (a, b) => {
//     console.log(a+b);
// }; 

// //for multifiction arrow function 
// const arrowMul = (a, b) => {
//     console.log(a*b); 
// };

//practice return vowels 

// function countVowels(str){
//     //"Brijkishor", count = 0; 
//     let count = 0; 
//     for(const char of str){
//         console.log(char); 
//         if(char == "a" || char == "e" || char == "i" || char == "o" || char == "u"){
//             count++;
//         }
//     }

//     console.log(count); 
// }

// countVowels("gla")

//forEach loop 

// let arr = [1, 2, 3, 4, 5]; 

// arr.forEach(function printVal(val) {
//     console.log(val); 
// });


// let arr = [1, 2, 3, 4, 5]; 

// arr.forEach((val) => {
//     console.log(val); 
// });

//Map

// let nums = [67, 52, 39]; 

// let newArr = nums.map((val) => {
//     return val * 2; 
// })

// console.log(newArr); 

// let calSquare = (num) => {
//     console.log(num * num);
// };

//filter method 

// let arr = [1, 2, 3, 4, 5, 6, 7];

// let evenArr = arr.filter((val) => {
//     return val % 2 != 0;
// });

// console.log(evenArr)

//Reduce method 

let arr = [5, 6, 2, 1, 101, 31]; 

const output = arr.reduce((prev, curr) => {
    return prev > curr ? prev : curr; 
});

console.log(output); 