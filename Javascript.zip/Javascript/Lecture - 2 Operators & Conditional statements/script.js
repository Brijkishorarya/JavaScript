// console.log("hello world!"); 
//This is a comment

//Arithmetic Operators 
// let a = 5; 
// let b = 2; 
// let c = a + b; 
// console.log("a = ", a, " & b = ", b);
// console.log("a + b = ", a + b);
// console.log("a - b = ", a - b);
// console.log("a * b = ", a * b);
// console.log("a / b = ", a / b);
// console.log("a % b = ", a % b);
// console.log("a ** b = ", a ** b);

//Unary operators 

// let a = 5; 
// let b = 2;

// console.log("a = ", a, " & b = ", b);
// a++; //6
// console.log("a = ", a); 

//Assignment operators 
// let a = 5; 
// let b = 2;

// a += 4; 
// console.log("a = ", a); 
// a -= 4; 
// console.log("a = ", a); 
// a *= 4; 
// console.log("a = ", a); 
// a /= 4; 
// console.log("a = ", a); 
// a **= 4; 

//Comparison operators 
// let a = 5; //number 
// let b = "5"; //String -> convert number implicity
// let c = 2; 

// console.log(a, "==", b, a == b); 
// console.log(a, "!=", b, a != b); 
// console.log(a, "==", b, a === b); //strictly check equal to or type

// console.log("5 >= 2", a >= c); 

//logical AND Operators 
// let a = 6; 
// let b = 5; 

// let cond1 = a > b; //true; 
// let cond2 = a === 6; //true; 
// console.log("cond1 && cond2 = ", cond1 && cond2); 

// let cond3 = a < b; //true; 
// let cond4 = a === 6; //true; 
// console.log("cond3 && cond4 = ", cond3 && cond4); 

//logical Or Operators 
// let a = 6; 
// let b = 5; 

// let cond1 = a > b; //true; 
// let cond2 = a === 6; //true; 
// console.log("cond1 || cond2 = ", cond1 || cond2); //true

// let cond3 = a < b; //true; 
// let cond4 = a === 6; //true; 
// console.log("cond3 || cond4 = ", cond3 && cond4); //true

// let a = 6; 
// let b = 5;

// console.log("!(6<5) = ", !(a === 6)); 


//Conditional statements 

// let age = 25; 

// if(age > 18){
//     console.log("You can vote"); 
// }

// if(age < 18){
//     console.log("You can't vote"); 
// }

// let age = 25; 

// if(age > 18){
//     console.log("You can vote"); 
// } else{
//     console.log("You can't vote")
// }

//Ternary operators 
// let age = 16; 

// let result = age >= 18 ? "adult" : "not adult"; 
// console.log(result); 

//practice 
let score = prompt("enter your score (0 - 100)"); 
let grade; 

if(score >= 90 && score <= 100){
    grade = 'A'; 
} else if(score >= 70 && score <= 89){
    grade = "B"; 
} else if(score >= 60 && score <= 69){
    grade = "C"; 
} else if(score >= 50 && score <= 59){
    grade = "D";
} else if(score >= 0 && score <= 49){
    grade = "F"; 
}

console.log("Accoring to your scores, your grade was : ", grade); 




