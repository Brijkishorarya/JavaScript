// console.log("Hello"); 

// alert("hii backlol")

// console.dir(window)
// console.dir(window.document)
// console.dir(document.body)

// console.dir(document.body.childNodes[1]);

// let heading = document.getElementById("heading"); 
// console.dir(heading)

// let headings = document.getElementsByClassName("myClass");
// console.dir(headings); 
// console.log(headings)

// let firstEl = document.querySelector("#myId"); 
// console.dir(firstEl);

// let allEl = document.querySelectorAll(".myClass");
// console.dir(allEl); 


// let firstEl = document.querySelector("P"); 
// console.dir(firstEl);

let div = document.querySelector("div"); 
console.log(div);

let heading = document.querySelector("h1")

