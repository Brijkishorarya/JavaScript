let h2 = document.querySelector("h2"); 
console.dir(h2.innerText);  

h2.innerText = h2.innerText + " from Apna college students";

let divs = document.querySelector(".box")
console.log(divs[0]); 